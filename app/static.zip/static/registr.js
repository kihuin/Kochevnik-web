function handleInput(input) {
    let placeholderText;
    let isPasswordMatch = true;

    switch (input.className) {
        case 'phone':
            placeholderText = 'Телефон';
            break;
        case 'password':
            placeholderText = 'Пароль';
            break;
        case 'password1':
            placeholderText = 'Подтверждение пароля';
            const passwordInput = document.getElementById('password');
            isPasswordMatch = input.value === passwordInput.value;
            break;
        case 'cod':
            placeholderText = 'Код из SMS';
            break;
        default:
            placeholderText = '';
    }

    const inputValue = input.value.trim();

    // Если введен хотя бы один символ, заменяем текст
    if (inputValue.length > 0) {
        input.placeholder = '';

        // Если пароли не совпадают, добавляем стиль и текст предупреждения
        if (input.className === 'password1' && !isPasswordMatch) {
            input.style.borderColor = 'red';
            input.nextElementSibling.textContent = 'Пароли не совпадают';
        } else {
            input.style.borderColor = ''; // Сбрасываем стиль при правильном вводе
            input.nextElementSibling.textContent = ''; // Очищаем текст предупреждения
        }
    } else {
        input.placeholder = placeholderText;
    }
}